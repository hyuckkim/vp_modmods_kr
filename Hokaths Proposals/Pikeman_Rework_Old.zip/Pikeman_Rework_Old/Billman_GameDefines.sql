-- Art
--==========================================================================================================================
-- IconTextureAtlases
--==========================================================================================================================
INSERT INTO IconTextureAtlases 
		(Atlas, 						IconSize, 	Filename, 						IconsPerRow, 	IconsPerColumn)
VALUES	('BILLMAN_ATLAS', 				256, 		'Billman256.dds',	1, 				1),
		('BILLMAN_ATLAS', 				128, 		'Billman128.dds',	1, 				1),
		('BILLMAN_ATLAS', 				80, 		'Billman80.dds',	1, 				1),
		('BILLMAN_ATLAS', 				64, 		'Billman64.dds',	1, 				1),
		('BILLMAN_ATLAS', 				45, 		'Billman45.dds',	1, 				1),
		('BILLMAN_Flag', 				32, 		'BillmanFlag_32.dds',			1, 				1);
--==========================================================================================================================
-- ArtDefine_StrategicView
--==========================================================================================================================
INSERT INTO ArtDefine_StrategicView(StrategicViewType, TileType, Asset)
 VALUES ('ART_DEF_UNIT_BILLMAN', 'Unit', 'BillmanFlag_128.dds');
--==========================================================================================================================
-- ArtDefine_UnitInfos
--==========================================================================================================================
INSERT INTO ArtDefine_UnitInfos (Type,DamageStates,Formation)
SELECT	('ART_DEF_UNIT_BILLMAN'), DamageStates, Formation
FROM ArtDefine_UnitInfos WHERE (Type = 'ART_DEF_UNIT_PIKEMAN');
--==========================================================================================================================
-- ArtDefine_UnitInfoMemberInfos
--==========================================================================================================================
INSERT INTO ArtDefine_UnitInfoMemberInfos (UnitInfoType,UnitMemberInfoType,NumMembers)
SELECT	('ART_DEF_UNIT_BILLMAN'), ('ART_DEF_UNIT_MEMBER_BILLMAN'), NumMembers
FROM ArtDefine_UnitInfoMemberInfos WHERE (UnitInfoType = 'ART_DEF_UNIT_PIKEMAN');
--==========================================================================================================================
-- ArtDefine_UnitMemberCombats
--==========================================================================================================================
INSERT INTO ArtDefine_UnitMemberCombats (UnitMemberType, EnableActions, DisableActions, MoveRadius, ShortMoveRadius, ChargeRadius, AttackRadius, RangedAttackRadius, MoveRate, ShortMoveRate, TurnRateMin, TurnRateMax, TurnFacingRateMin, TurnFacingRateMax, RollRateMin, RollRateMax, PitchRateMin, PitchRateMax, LOSRadiusScale, TargetRadius, TargetHeight, HasShortRangedAttack, HasLongRangedAttack, HasLeftRightAttack, HasStationaryMelee, HasStationaryRangedAttack, HasRefaceAfterCombat, ReformBeforeCombat, HasIndependentWeaponFacing, HasOpponentTracking, HasCollisionAttack, AttackAltitude, AltitudeDecelerationDistance, OnlyTurnInMovementActions, RushAttackFormation)
SELECT	('ART_DEF_UNIT_MEMBER_BILLMAN'), EnableActions, DisableActions, MoveRadius, ShortMoveRadius, ChargeRadius, AttackRadius, RangedAttackRadius, MoveRate, ShortMoveRate, TurnRateMin, TurnRateMax, TurnFacingRateMin, TurnFacingRateMax, RollRateMin, RollRateMax, PitchRateMin, PitchRateMax, LOSRadiusScale, TargetRadius, TargetHeight, HasShortRangedAttack, HasLongRangedAttack, HasLeftRightAttack, HasStationaryMelee, HasStationaryRangedAttack, HasRefaceAfterCombat, ReformBeforeCombat, HasIndependentWeaponFacing, HasOpponentTracking, HasCollisionAttack, AttackAltitude, AltitudeDecelerationDistance, OnlyTurnInMovementActions, RushAttackFormation
FROM ArtDefine_UnitMemberCombats WHERE (UnitMemberType = 'ART_DEF_UNIT_MEMBER_PIKEMAN');
--==========================================================================================================================
-- ArtDefine_UnitMemberCombatWeapons
--==========================================================================================================================
INSERT INTO ArtDefine_UnitMemberCombatWeapons (UnitMemberType, "Index", SubIndex, ID, VisKillStrengthMin, VisKillStrengthMax, ProjectileSpeed, ProjectileTurnRateMin, ProjectileTurnRateMax, HitEffect, HitEffectScale, HitRadius, ProjectileChildEffectScale, AreaDamageDelay, ContinuousFire, WaitForEffectCompletion, TargetGround, IsDropped, WeaponTypeTag, WeaponTypeSoundOverrideTag)
SELECT ('ART_DEF_UNIT_MEMBER_BILLMAN'), "Index", SubIndex, ID, VisKillStrengthMin, VisKillStrengthMax, ProjectileSpeed, ProjectileTurnRateMin, ProjectileTurnRateMax, HitEffect, HitEffectScale, HitRadius, ProjectileChildEffectScale, AreaDamageDelay, ContinuousFire, WaitForEffectCompletion, TargetGround, IsDropped, WeaponTypeTag, WeaponTypeSoundOverrideTag
FROM ArtDefine_UnitMemberCombatWeapons WHERE (UnitMemberType = 'ART_DEF_UNIT_MEMBER_PIKEMAN');
--==========================================================================================================================
-- ArtDefine_UnitMemberInfos
--==========================================================================================================================
INSERT INTO ArtDefine_UnitMemberInfos (Type, Scale, ZOffset, Domain, Model, MaterialTypeTag, MaterialTypeSoundOverrideTag)
SELECT	('ART_DEF_UNIT_MEMBER_BILLMAN'), Scale, ZOffset, Domain, ('Pikeman_England.fxsxml'), MaterialTypeTag, MaterialTypeSoundOverrideTag
FROM ArtDefine_UnitMemberInfos WHERE (Type = 'ART_DEF_UNIT_MEMBER_PIKEMAN');
--==========================================================================================================================
	
--=======================================================================================================================
-- GAME DEFINES
--==========================================================================================================================
-- UnitGameplay2DScripts
--==========================================================================================================================
INSERT INTO UnitClasses
	(Type, Description, DefaultUnit)
VALUES
	('UNITCLASS_BILLMAN', 'TXT_KEY_UNIT_BILLMAN', 'UNIT_BILLMAN');

INSERT OR REPLACE INTO Language_en_US 
	(Tag, Text)
Values 
	('TXT_KEY_UNIT_BILLMAN', 'Halberdier');

--=======================================================================================================================
-- Units
--=======================================================================================================================
INSERT INTO Units 	
		(Type, 			Class, PrereqTech,	Combat,	Cost, FaithCost, RequiresFaithPurchaseEnabled,	GlobalFaithPurchaseCooldown, PurchaseCooldown, Moves, CombatClass, Domain, DefaultUnitAI, Description, 				Strategy, 						Help, 						Civilopedia, 				MilitarySupport, MilitaryProduction, Pillage, IgnoreBuildingDefense, AdvancedStartCost, GoodyHutUpgradeUnitClass, CombatLimit, BaseLandAirDefense, Conscription, XPValueAttack, XPValueDefense, UnitArtInfo, 					UnitFlagAtlas,				UnitFlagIconOffset, IconAtlas,		PortraitIndex, 	MoveRate, ObsoleteTech)
SELECT	'UNIT_BILLMAN',	'UNITCLASS_BILLMAN', 'TECH_METAL_CASTING',	16, 110, 250, 1, 							GlobalFaithPurchaseCooldown, PurchaseCooldown, Moves, CombatClass, Domain, DefaultUnitAI, 'TXT_KEY_UNIT_BILLMAN', 	'TXT_KEY_UNIT_BILLMAN_STRATEGY',	'TXT_KEY_UNIT_BILLMAN_HELP',	'TXT_KEY_UNIT_BILLMAN_TEXT',	MilitarySupport, MilitaryProduction, Pillage, IgnoreBuildingDefense, AdvancedStartCost, GoodyHutUpgradeUnitClass, CombatLimit, BaseLandAirDefense, Conscription, XPValueAttack, XPValueDefense, 'ART_DEF_UNIT_BILLMAN',	'BILLMAN_Flag',	0,					'BILLMAN_ATLAS',	0, 				MoveRate, 'TECH_MACHINERY'
FROM Units WHERE Type = 'UNIT_PIKEMAN';

INSERT INTO Unit_BuildingClassPurchaseRequireds
	(UnitType, BuildingClassType)
VALUES
	('UNIT_BILLMAN', 'BUILDINGCLASS_BARRACKS');

INSERT OR REPLACE INTO Language_en_US 
	(Tag, Text)
Values 
	('TXT_KEY_UNIT_BILLMAN_STRATEGY', 'Stronger than the Spearman, but not able to stand up to the units of the Medieval Era. Use this Melee Unit to hold out against Knights until you can find an answer.'),	
	('TXT_KEY_UNIT_BILLMAN_HELP', 'Basic Melee Unit that upgrades from the Spearman. Starts with Formation I.'),	
	('TXT_KEY_UNIT_BILLMAN_TEXT', 'A number of poleaxe designs were used in combat, with most developed from peasants combining hand tools with spear shafts. They all served roughly the same function as a melee weapon that could also function against a mounted foe. For example, bills are a class of agricultural implement used for trimming tree limbs, which were often repurposed for use as an infantry polearm when peasants were levied to fight in war. It was similar in size, function and appearance to the contemporary halberd: a long pole at the end of which is a hook for grappling and an axe and/or spike for cutting/thrusting. By the 15th century it had largely been replaced by the pike, though the English continued to use a combination of billmen and longbowmen into the early 16th century.');

INSERT OR REPLACE INTO Language_en_US 
	(Tag, Text)
Values
	('TXT_KEY_UNIT_PIKEMAN_STRATEGY', 'The Pikeman is a more powerful Halberdier. Its higher combat strength allows it to stand up against rampaging Knights. A fortified Pikeman is a Knight''s worst nightmare. After unlocking Gunpowder, recreate the Pike and Shot strategy by using the free Formation I to quickly gain the Arquebusiers Promotion.'), 
	('TXT_KEY_CIVILOPEDIA_UNITS_MEDIEVAL_PIKEMAN_TEXT', 'A pikeman is better trained and weilding a more sophisticated weapon than their predecessors. Generally defined as becoming a pike, rather than a spear, when it becomes too long to wield one-handed, these weapons were between 3 to 7 meters (10 to 23 ft) long. Due to their extreme length, the shaft near the head was often reinforced with metal strips called langets, and strong wood such as well-seasoned ash had to be used for the pole, which was tapered towards the point to prevent the pike from sagging. From the 14th Century pikes formed the defensive core of many European armies, especially after the advent of gunpowder, where they defended the musket-users from attack. Even without ranged support, better-trained troops were capable of using the pike in an aggressive attack. However in close quarters the weapon is unwieldy, and pikemen were usually sparsely prepared to fight in a melee, or to defend against heavy arrowfire.');

UPDATE Language_en_US
SET Text = 'Unique Danish {TXT_KEY_UNIT_BILLMAN} that is adept at attacking from the coast. Starts with [COLOR_POSITIVE_TEXT]{TXT_KEY_PROMOTION_AMPHIBIOUS}[ENDCOLOR] and [COLOR_POSITIVE_TEXT]{TXT_KEY_PROMOTION_CHARGE}[ENDCOLOR].'
WHERE Tag = 'TXT_KEY_CIV5_DENMARK_BERSERKER_HELP';

UPDATE Language_en_US
SET Text = 'The {TXT_KEY_UNIT_DANISH_BERSERKER} is a Danish Unique Unit, replacing the {TXT_KEY_UNIT_BILLMAN}. It can cross rivers and attack while embarked with no penalty, and has a [ICON_STRENGTH] Combat Strength bonus against wounded units. It is also faster, allowing it to catch up to wounded units to deal the final strike.'
WHERE Tag = 'TXT_KEY_CIV5_DENMARK_BERSERKER_STRATEGY';

UPDATE Units SET
Class = 'UNITCLASS_BILLMAN'
WHERE Type = 'UNIT_DANISH_BERSERKER';

UPDATE Unit_ClassUpgrades SET 
UnitClassType = 'UNITCLASS_PIKEMAN' 
WHERE UnitType = 'UNIT_DANISH_BERSERKER';

UPDATE Civilization_UnitClassOverrides SET UnitClassType = 'UNITCLASS_BILLMAN' WHERE UnitType = 'UNIT_DANISH_BERSERKER';

UPDATE Units SET
	PrereqTech = 'TECH_MACHINERY', 
	Cost = 150,
	FaithCost = 325,
	Combat = 20
WHERE Type IN (SELECT a.Type FROM Units a WHERE a.Class = 'UNITCLASS_PIKEMAN');

UPDATE Units SET
	Cost = 110,
	Combat = 22
WHERE Type = 'UNIT_NETHERLANDS_GOEDENDAG';

--==========================================================================================================================
-- UnitGameplay2DScripts
--==========================================================================================================================
INSERT INTO UnitGameplay2DScripts
		(UnitType, 		SelectionSound, FirstSelectionSound)
SELECT	'UNIT_BILLMAN', 	SelectionSound, FirstSelectionSound
FROM UnitGameplay2DScripts WHERE (UnitType = 'UNIT_PIKEMAN');
--==========================================================================================================================
-- Unit_AITypes
--==========================================================================================================================
INSERT INTO Unit_AITypes
		(UnitType, 		UnitAIType)
SELECT	'UNIT_BILLMAN', 	UnitAIType
FROM Unit_AITypes WHERE (UnitType = 'UNIT_PIKEMAN');
--==========================================================================================================================
-- Unit_ClassUpgrades
--==========================================================================================================================
UPDATE Unit_ClassUpgrades SET
UnitClassType	= 'UNITCLASS_BILLMAN'
WHERE UnitType IN (SELECT Type FROM Units WHERE Class = 'UNITCLASS_SPEARMAN');

INSERT INTO Unit_ClassUpgrades 
	(UnitType, UnitClassType)
VALUES
	('UNIT_BILLMAN', 'UNITCLASS_PIKEMAN');

-- find the UUs, find all the UUs
UPDATE Units SET
ObsoleteTech = 'TECH_MACHINERY'
WHERE Class = 'UNITCLASS_SPEARMAN';

UPDATE Units SET
ObsoleteTech = 'TECH_METAL_CASTING'
WHERE Type = 'UNIT_SPEARMAN';
--==========================================================================================================================
-- Unit_Flavors
--==========================================================================================================================
INSERT INTO Unit_Flavors
		(UnitType, 		FlavorType, Flavor)
SELECT	'UNIT_BILLMAN', 	FlavorType, Flavor
FROM Unit_Flavors WHERE (UnitType = 'UNIT_PIKEMAN');

UPDATE Unit_Flavors SET Flavor = 6 WHERE (FlavorType = 'FLAVOR_OFFENSE' AND UnitType = 'UNIT_PIKEMAN');
--==========================================================================================================================
-- Unit_FreePromotions
--==========================================================================================================================
INSERT INTO Unit_FreePromotions
		(UnitType, 		PromotionType)
SELECT	'UNIT_BILLMAN', 	PromotionType
FROM Unit_FreePromotions WHERE (UnitType = 'UNIT_SPEARMAN');
--==========================================================================================================================
-- UnitPromotions
--==========================================================================================================================
UPDATE UnitPromotions SET
	CannotBeChosen = 0,
	LostWithUpgrade = 0,
	PromotionPrereqOr1 = 'PROMOTION_FORMATION_2',
	TechPrereq = 'TECH_GUNPOWDER',
	RankList = 'FORMATION',
	RankNumber = 3,
	OpenDefense = 15,
	OrderPriority = 301,
	MaxHitPointsChange = 10,
	PortraitIndex = 57
WHERE Type = 'PROMOTION_DOPPELSOLDNER';

INSERT INTO UnitPromotions_UnitCombats
	(PromotionType, UnitCombatType)
VALUES 
	('PROMOTION_DOPPELSOLDNER', 'UNITCOMBAT_MELEE');

INSERT OR REPLACE INTO Language_en_US 
	(Tag, Text)
Values 
	('TXT_KEY_PROMOTION_DOPPELSOLDNER', 'Formation III'),
	('TXT_KEY_PROMOTION_DOPPELSOLDNER_HELP', '+30% [ICON_STRENGTH] Combat Strength when attacking [COLOR_POSITIVE_TEXT]Full Health Units[ENDCOLOR].[NEWLINE]+15% [ICON_STRENGTH] Combat Strength when defending in [COLOR_POSITIVE_TEXT]Open Terrain[ENDCOLOR][NEWLINE]+10 Hit Points.'),
	('TXT_KEY_PIKE_AND_SHOT', 'Pike-and-Shot'),
	('TXT_KEY_SNOEK_AND_SCHOT', 'Piek-en-Schot');

INSERT INTO UnitPromotions_UnitName
	(PromotionType, UnitType, Name)
VALUES
	('PROMOTION_DOPPELSOLDNER', 'UNIT_PIKEMAN', 'TXT_KEY_PIKE_AND_SHOT'),
	('PROMOTION_DOPPELSOLDNER', 'UNIT_NETHERLANDS_GOEDENDAG', 'TXT_KEY_SNOEK_AND_SCHOT');

