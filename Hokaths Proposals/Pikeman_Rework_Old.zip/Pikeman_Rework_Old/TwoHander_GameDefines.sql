----------------------------------------------------
-- ArtDef
----------------------------------------------------
INSERT INTO ArtDefine_UnitInfos 
			(Type, 							DamageStates,	Formation)
SELECT		('ART_DEF_UNIT_2HANDER'),		DamageStates, 	Formation
FROM ArtDefine_UnitInfos WHERE (Type = 'ART_DEF_UNIT_LONGSWORDSMAN');

INSERT INTO ArtDefine_UnitMemberInfos 	
			(Type, 										Scale,  ZOffset, Domain, Model, 			MaterialTypeTag, MaterialTypeSoundOverrideTag)
SELECT		('ART_DEF_UNIT_MEMBER_2HANDER'),	Scale,	ZOffset, Domain, ('2hswordsman_black.fxsxml'),	('ARMOR'), ('ARMOR')
FROM ArtDefine_UnitMemberInfos WHERE (Type = 'ART_DEF_UNIT_MEMBER_LONGSWORDSMAN');

INSERT INTO ArtDefine_UnitInfoMemberInfos 	
			(UnitInfoType,							UnitMemberInfoType,			NumMembers)
SELECT		('ART_DEF_UNIT_2HANDER'),		('ART_DEF_UNIT_MEMBER_2HANDER'),	NumMembers
FROM ArtDefine_UnitInfoMemberInfos WHERE (UnitInfoType = 'ART_DEF_UNIT_LONGSWORDSMAN');

INSERT INTO ArtDefine_UnitMemberCombats 
			(UnitMemberType,							EnableActions, DisableActions, MoveRadius, ShortMoveRadius, ChargeRadius, AttackRadius, RangedAttackRadius, MoveRate, ShortMoveRate, TurnRateMin, TurnRateMax, TurnFacingRateMin, TurnFacingRateMax, RollRateMin, RollRateMax, PitchRateMin, PitchRateMax, LOSRadiusScale, TargetRadius, TargetHeight, HasShortRangedAttack, HasLongRangedAttack, HasLeftRightAttack, HasStationaryMelee, HasStationaryRangedAttack, HasRefaceAfterCombat, ReformBeforeCombat, HasIndependentWeaponFacing, HasOpponentTracking, HasCollisionAttack, AttackAltitude, AltitudeDecelerationDistance, OnlyTurnInMovementActions, RushAttackFormation)
SELECT		('ART_DEF_UNIT_MEMBER_2HANDER'),	EnableActions, DisableActions, MoveRadius, ShortMoveRadius, ChargeRadius, AttackRadius, RangedAttackRadius, MoveRate, ShortMoveRate, TurnRateMin, TurnRateMax, TurnFacingRateMin, TurnFacingRateMax, RollRateMin, RollRateMax, PitchRateMin, PitchRateMax, LOSRadiusScale, TargetRadius, TargetHeight, HasShortRangedAttack, HasLongRangedAttack, HasLeftRightAttack, HasStationaryMelee, HasStationaryRangedAttack, HasRefaceAfterCombat, ReformBeforeCombat, HasIndependentWeaponFacing, HasOpponentTracking, HasCollisionAttack, AttackAltitude, AltitudeDecelerationDistance, OnlyTurnInMovementActions, RushAttackFormation
FROM ArtDefine_UnitMemberCombats WHERE (UnitMemberType = 'ART_DEF_UNIT_MEMBER_LONGSWORDSMAN');

INSERT INTO ArtDefine_UnitMemberCombatWeapons	
			(UnitMemberType,					"Index", SubIndex, ID, VisKillStrengthMin, VisKillStrengthMax, ProjectileSpeed, ProjectileTurnRateMin, ProjectileTurnRateMax, HitEffect, HitEffectScale, HitRadius, ProjectileChildEffectScale, AreaDamageDelay, ContinuousFire, WaitForEffectCompletion, TargetGround, IsDropped, WeaponTypeTag, WeaponTypeSoundOverrideTag)
SELECT		('ART_DEF_UNIT_MEMBER_2HANDER'),	"Index", SubIndex, ID, VisKillStrengthMin, VisKillStrengthMax, ProjectileSpeed, ProjectileTurnRateMin, ProjectileTurnRateMax, HitEffect, HitEffectScale, HitRadius, ProjectileChildEffectScale, AreaDamageDelay, ContinuousFire, WaitForEffectCompletion, TargetGround, IsDropped, ('METAL'), ('SWORD')
FROM ArtDefine_UnitMemberCombatWeapons WHERE (UnitMemberType = 'ART_DEF_UNIT_MEMBER_LONGSWORDSMAN');

INSERT INTO ArtDefine_StrategicView 
			(StrategicViewType, 			TileType,	Asset)
VALUES		('ART_DEF_UNIT_2HANDER', 		'Unit', 	'sv_2hander.dds');

----------------------------------------------------
-- Icons
----------------------------------------------------

INSERT INTO IconTextureAtlases (Atlas, IconSize, Filename, IconsPerRow, IconsPerColumn) VALUES
('RER_UNITS_ATLAS',	256, 'RER_UNITS_atlas_256.dds', 2, 1),
('RER_UNITS_ATLAS',	128, 'RER_UNITS_atlas_128.dds', 2, 1),
('RER_UNITS_ATLAS',	 80, 'RER_UNITS_atlas_80.dds',  2, 1),
('RER_UNITS_ATLAS',	 64, 'RER_UNITS_atlas_64.dds',  2, 1),
('RER_UNITS_ATLAS',	 45, 'RER_UNITS_atlas_45.dds',  2, 1),
('vpee_promoAtlas', 256, 'VPEE_promo_icons_256.dds', '8', '1'),
('vpee_promoAtlas', 64, 'VPEE_promo_icons_064.dds', '8', '1'),
('vpee_promoAtlas', 45, 'VPEE_promo_icons_045.dds', '8', '1'),
('vpee_promoAtlas', 32, 'VPEE_promo_icons_032.dds', '8', '1'),
('vpee_promoAtlas', 16, 'VPEE_promo_icons_016.dds', '8', '1'),
('LandsknechtAtlas', 32, 'AGLA_BAVMAX_UnitFlag_32.dds', '1', '1');

----------------------------------------------------
-- Unit
----------------------------------------------------
INSERT INTO UnitClasses (Type, DefaultUnit, Description)
VALUES ('UNITCLASS_2HANDER', 'UNIT_2HANDER', 'TXT_KEY_UNIT_2HANDER');

INSERT INTO Units 
	(Class, Type, PrereqTech, Combat, Cost, FaithCost, RequiresFaithPurchaseEnabled, Moves, CombatClass, Domain, DefaultUnitAI, 
	Description, Civilopedia, Strategy, Help,
	MilitarySupport, MilitaryProduction, Pillage, ObsoleteTech, GoodyHutUpgradeUnitClass, AdvancedStartCost, PurchaseCooldown,
	XPValueAttack, XPValueDefense, Conscription, UnitArtInfo, UnitFlagIconOffset, IconAtlas, PortraitIndex)
VALUES
	('UNITCLASS_2HANDER', 'UNIT_2HANDER','TECH_CHEMISTRY', 24, 300, 400, 1, 2, 'UNITCOMBAT_MELEE', 'DOMAIN_LAND', 'UNITAI_ATTACK',
	'TXT_KEY_UNIT_2HANDER',	'TXT_KEY_CIV5_2HANDER_TEXT', 'TXT_KEY_UNIT_2HANDER_STRATEGY', 'TXT_KEY_UNIT_HELP_2HANDER',
	1, 1, 1, 'TECH_RIFLING', 'UNITCLASS_RIFLEMAN', 25, 1,
	3, 3, 3, 'ART_DEF_UNIT_2HANDER', 33, 'RER_UNITS_ATLAS', 0);


INSERT INTO Unit_BuildingClassPurchaseRequireds
	(UnitType, BuildingClassType)
VALUES 
	('UNIT_2HANDER', 'BUILDINGCLASS_ARMORY');

UPDATE Units SET UnitFlagAtlas = 'LandsknechtAtlas' WHERE Type = 'UNIT_GERMAN_LANDSKNECHT';
UPDATE Units SET UnitFlagIconOffset = 0 WHERE Type = 'UNIT_GERMAN_LANDSKNECHT';

INSERT INTO UnitGameplay2DScripts (UnitType, SelectionSound, FirstSelectionSound)
VALUES ('UNIT_2HANDER', 'AS2D_SELECT_SWORDSMAN', 'AS2D_BIRTH_SWORDSMAN');

DELETE FROM Unit_ClassUpgrades WHERE UnitType IN ('UNIT_FCOMPANY', 'UNIT_HUN_BATTERING_RAM');

INSERT INTO Unit_ClassUpgrades 
	(UnitType, UnitClassType)
VALUES 
	('UNIT_2HANDER', 'UNITCLASS_RIFLEMAN'),
	('UNIT_FCOMPANY', 'UNITCLASS_RIFLEMAN'),
	('UNIT_HUN_BATTERING_RAM', 'UNITCLASS_PIKEMAN');

-- update Longswordsman and pikeman
UPDATE Unit_ClassUpgrades
SET UnitClassType = 'UNITCLASS_2HANDER'
WHERE UnitType IN (SELECT Type FROM Units WHERE Class = 'UNITCLASS_LONGSWORDSMAN');

UPDATE Units
SET ObsoleteTech = 'TECH_CHEMISTRY', GoodyHutUpgradeUnitClass = 'UNITCLASS_2HANDER'
WHERE Type = 'UNIT_LONGSWORDSMAN';

UPDATE Unit_ClassUpgrades
SET UnitClassType = 'UNITCLASS_RIFLEMAN'
WHERE UnitType IN (SELECT Type FROM Units WHERE Class = 'UNITCLASS_PIKEMAN');

UPDATE Units
SET ObsoleteTech = 'TECH_RIFLING', GoodyHutUpgradeUnitClass = 'UNITCLASS_RIFLEMAN'
WHERE Type = 'UNIT_PIKEMAN';

---UNIQUE UNITS----

UPDATE Civilization_UnitClassOverrides 
SET UnitClassType = 'UNITCLASS_2HANDER'
WHERE UnitClassType = 'UNITCLASS_TERCIO';

UPDATE Units SET
Class = 'UNITCLASS_2HANDER',
Combat = 27
WHERE Type = 'UNIT_FRENCH_MUSKETEER';

UPDATE Language_en_US
SET Text = 'Unique French {TXT_KEY_UNIT_2HANDER} that excels at delivering a fast attack into the enemy and does not require [ICON_RES_IRON] Iron. Can move faster and ignore Zone of Control.'
WHERE Tag = 'TXT_KEY_UNIT_HELP_MUSKETEER';

UPDATE Language_en_US
SET Text = 'The {TXT_KEY_UNIT_FRENCH_MUSKETEER} is a French Unique Unit, replacing the {TXT_KEY_UNIT_2HANDER}. It is a very different Unit, unlocking at Gunpowder instead of Chemistry and not requiring any strategic resources to build. It is significantly more powerful, and has different promotions which allow it to move faster and ignore Zone of Control.'
WHERE Tag = 'TXT_KEY_UNIT_FRENCH_MUSKETEER_STRATEGY';


UPDATE Units SET
Class = 'UNITCLASS_2HANDER', PrereqTech = 'TECH_CHEMISTRY'
WHERE Type = 'UNIT_GERMAN_LANDSKNECHT';

UPDATE Language_en_US
SET Text = 'Doppelsoeldner'
WHERE Tag = 'TXT_KEY_UNIT_GERMAN_LANDSKNECHT';


UPDATE Civilization_UnitClassOverrides 
SET UnitClassType = 'UNITCLASS_PIKEMAN'
WHERE UnitType = 'UNIT_ZULU_IMPI';

UPDATE Units SET
Class = 'UNITCLASS_PIKEMAN', Combat = 24, Cost = 200, PrereqTech = 'TECH_MACHINERY'
WHERE Type = 'UNIT_ZULU_IMPI';

UPDATE Language_en_US
SET Text = 'Unique Zulu {TXT_KEY_UNIT_PIKEMAN} that excels at defeating Gunpowder Units. Starts with the Javelin Volley Promotion. Also starts with Cover I.'
WHERE Tag = 'TXT_KEY_UNIT_HELP_ZULU_IMPI';

UPDATE Language_en_US
SET Text = 'Javelin Volley'
WHERE Tag = 'TXT_KEY_PROMOTION_RANGED_SUPPORT_FIRE';


UPDATE Language_en_US
SET Text = 'The {TXT_KEY_UNIT_ZULU_IMPI} is a Zulu Unique Unit, replacing the {TXT_KEY_UNIT_PIKEMAN}. Besides being much stronger and more expensive to build than the {TXT_KEY_UNIT_PIKEMAN}, it takes notably less compared to other contemporary units. Its shield gives it Cover I, reducing damage from ranged attacks, and before engaging in an melee attack, it performs a spear throw attack that weakens the defender before melee combat ensues. It also has a [ICON_STRENGTH] Combat Strength bonus when fighting against Gunpowder Units, making it a deadly unit well into the Industrial Era.'
WHERE Tag = 'TXT_KEY_UNIT_ZULU_IMPI_STRATEGY';

INSERT OR REPLACE INTO UnitPromotions_UnitCombatMods
	(PromotionType, UnitCombatType, Modifier)
VALUES
	('PROMOTION_KNOCKOUT', 'UNITCOMBAT_GUN', 50);

INSERT OR REPLACE INTO Language_en_US (Tag, Text) VALUES
('TXT_KEY_PROMOTION_KNOCKOUT_HELP', '+50% [ICON_STRENGTH] Combat Strength VS [COLOR_POSITIVE_TEXT]Gunpowder Units[ENDCOLOR].');

UPDATE Units SET
Class = 'UNITCLASS_2HANDER', PrereqTech = 'TECH_CHEMISTRY'
WHERE Type = 'UNIT_SHOSHONE_YELLOW_BROW';

INSERT OR REPLACE INTO Language_en_US
	(Tag, Text)
VALUES
	('TXT_KEY_UNIT_SHOSHONE_YELLOW_BROW_HELP', 'Unique Shoshone {TXT_KEY_UNIT_2HANDER} that is much stronger defensively and does not require [ICON_RES_IRON] Iron. Starts with the Formation I instead of Two Hander, and also gains [ICON_STRENGTH] Strength when damaged, and a double [ICON_STRENGTH] Combat bonus from fortifying.'); 

INSERT OR REPLACE INTO Language_en_US
	(Tag, Text)
VALUES
	('TXT_KEY_UNIT_SHOSHONE_YELLOW_BROW_STRATEGY', 'The Yellow Brow is unmatched for its ability to hold ground. Never one to retreat, the Yellow brow fights at full strength regardless of health, and has double the normal bonus from fortifying. A generally very hardy unit for its time, it is particularly effective against enemy mounted Units.');


UPDATE Language_en_US SET Text = 'Greatswordsman' WHERE Tag = 'TXT_KEY_UNIT_SPANISH_TERCIO';  -- so text tooltips refer to the right unit

UPDATE Units SET 
PrereqTech = NULL,
Cost = -1
WHERE Type = 'UNIT_SPANISH_TERCIO';  

-- let's not obliterate it, that might mess up bad

----------------------------------------------------
-- Promotions
----------------------------------------------------
DELETE FROM Unit_FreePromotions WHERE UnitType IN ('UNIT_GERMAN_LANDSKNECHT', 'UNIT_ZULU_IMPI');

INSERT INTO Unit_FreePromotions (UnitType, PromotionType) VALUES
('UNIT_2HANDER', 'PROMOTION_FIELD_WORKS_0'),
('UNIT_2HANDER', 'PROMOTION_2HANDER'),
('UNIT_GERMAN_LANDSKNECHT', 'PROMOTION_FIELD_WORKS_0'),
('UNIT_GERMAN_LANDSKNECHT', 'PROMOTION_2HANDER'),
('UNIT_GERMAN_LANDSKNECHT', 'PROMOTION_FORMATION_1'),
('UNIT_GERMAN_LANDSKNECHT', 'PROMOTION_FORMATION_2'),
('UNIT_ZULU_IMPI', 'PROMOTION_FORMATION_1'),
('UNIT_ZULU_IMPI', 'PROMOTION_COVER_1'),
('UNIT_ZULU_IMPI', 'PROMOTION_RANGED_SUPPORT_FIRE'),
('UNIT_ZULU_IMPI', 'PROMOTION_KNOCKOUT');

----------------------------------------------------
-- Other features
----------------------------------------------------

INSERT INTO Unit_ResourceQuantityRequirements (UnitType, ResourceType, Cost)
VALUES ('UNIT_2HANDER', 'RESOURCE_IRON', 1),
	  ('UNIT_GERMAN_LANDSKNECHT', 'RESOURCE_IRON', 1);

----------------------------------------------------
-- AI
----------------------------------------------------

INSERT INTO Unit_AITypes (UnitType, UnitAIType) VALUES
('UNIT_2HANDER', 'UNITAI_ATTACK'),
('UNIT_2HANDER', 'UNITAI_DEFENSE');

INSERT INTO Unit_Flavors (UnitType, FlavorType, Flavor) VALUES
('UNIT_2HANDER', 'FLAVOR_OFFENSE', 7),
('UNIT_2HANDER', 'FLAVOR_DEFENSE', 6);

----------------------------------------------------
-- Text (en_US)
----------------------------------------------------

INSERT INTO Language_en_US (Tag, Text) VALUES
('TXT_KEY_UNIT_2HANDER', 'Greatswordsman'),
('TXT_KEY_CIV5_2HANDER_TEXT', 'Renaissance two-handed swords are monstrous weapons, longer and larger than even the medieval longsword, with a hilt of over a foot and a blade that measures nearly five feet in length, taller than some people. They are primarily in use during the early decades of the 16th century. These swords represent the final stage in the trend of increasing size that started in the 14th century. They can be used to fight against pike formations and cut off pike heads.'),
('TXT_KEY_UNIT_2HANDER_STRATEGY', 'The Greatswordsman is much stronger than the Longswordsman, and gains a devastating combat bonus against Melee Units that start with Formation I.'),
('TXT_KEY_UNIT_HELP_2HANDER', 'Early Renaissance Era Melee Unit. Additional +33% [ICON_STRENGTH] Strength [COLOR_POSITIVE_TEXT]Attacking[ENDCOLOR] VS Spearmen, Billman, Pikemen, and Mercenaries.');
------------------------------------------------
----------------------------------------------------
-- Promo stuff
----------------------------------------------------

INSERT INTO UnitPromotions (Type, PediaType, IconAtlas, PortraitIndex, Sound) VALUES
('PROMOTION_2HANDER',        'PEDIA_MELEE',      'vpee_promoAtlas', 00,'AS2D_IF_LEVELUP');

UPDATE UnitPromotions
SET Description = 'TXT_KEY_'||Type, Help = 'TXT_KEY_'||Type||'_HELP', PediaEntry = 'TXT_KEY_'||Type, CannotBeChosen = 1
WHERE Type = 'PROMOTION_2HANDER';

----------------------------------------------------
-- Promotions' unique features
----------------------------------------------------

UPDATE UnitPromotions SET LostWithUpgrade = 1 WHERE Type = 'PROMOTION_2HANDER';
INSERT INTO UnitPromotions_UnitClasses (PromotionType, UnitClassType, Attack) VALUES
('PROMOTION_2HANDER', 'UNITCLASS_PIKEMAN', 33),
('PROMOTION_2HANDER', 'UNITCLASS_SPEARMAN', 33),
('PROMOTION_2HANDER', 'UNITCLASS_BILLMAN', 33),
('PROMOTION_2HANDER', 'UNITCLASS_FCOMPANY', 33);

----------------------------------------------------
-- Text (en_US)
----------------------------------------------------

INSERT INTO Language_en_US (Tag, Text) VALUES
('TXT_KEY_PROMOTION_2HANDER', 'Two Hander'),
('TXT_KEY_PROMOTION_2HANDER_HELP', '+33% [ICON_STRENGTH] Strength [COLOR_POSITIVE_TEXT]Attacking[ENDCOLOR] VS Spearman, Billman, Pikeman, and Free Companies. [COLOR_NEGATIVE_TEXT]Lost on upgrade[ENDCOLOR].');

-- Gunpowder

INSERT INTO UnitPromotions 
	(Type, Description, Help, Sound, 
	LostWithUpgrade, OrderPriority, CannotBeChosen, PortraitIndex, IconAtlas,	PediaType,	PediaEntry, CombatPercent) 
VALUES 
	('PROMOTION_ARQUEBUS', 'TXT_KEY_PROMOTION_ARQUEBUS',	'TXT_KEY_PROMOTION_ARQUEBUS_HELP',	'AS2D_IF_LEVELUP',	
	1, 1,	1, 56, 'extraPromo_Atlas', 'PEDIA_MELEE', 'TXT_KEY_PROMOTION_ARQUEBUS', 25);

INSERT INTO Technology_FreePromotions
	(TechType, PromotionType)
VALUES
	('TECH_GUNPOWDER', 'PROMOTION_ARQUEBUS');

INSERT INTO UnitPromotions_UnitCombats
	(PromotionType, UnitCombatType)
VALUES 
	('PROMOTION_ARQUEBUS', 'UNITCOMBAT_MELEE');

INSERT OR REPLACE INTO Language_en_US 
	(Tag, Text)
Values 
	('TXT_KEY_PROMOTION_ARQUEBUS', 'Matchlock'),
	('TXT_KEY_PROMOTION_ARQUEBUS_HELP', '+20% [ICON_STRENGTH] Combat Strength.[NEWLINE][COLOR_NEGATIVE_TEXT]Lost on upgrade[ENDCOLOR] to a Gunpowder Unit.');


