-- covert action 

UPDATE Policies
SET
	FreeSpy = 1,
	RigElectionInfluenceModifier = 50,
	EspionageNetworkPoints = 0
WHERE Type = 'POLICY_COVERT_ACTION';

UPDATE Language_en_US
SET Text = '[COLOR_POSITIVE_TEXT]Covert Action[ENDCOLOR]: Receive 100 [ICON_VP_SPY_POINTS] Spy Points. The [ICON_CAPITAL] Capital gains +3% [ICON_GOLD] Gold for every 100 [ICON_VP_SPY_POINTS] Spy Points ever accumulated (up to 30%). When successfully [ICON_PUPPET] Rigging an election in a City-State, the [ICON_INFLUENCE] Influence you gain and other Players lose is increased by +50%.'
WHERE Tag = 'TXT_KEY_POLICY_COVERT_ACTION_HELP';

INSERT INTO Policy_YieldModifierFromActiveSpies
	(PolicyType, YieldType, Yield)
VALUES
	('POLICY_COVERT_ACTION', 'YIELD_GOLD', 3);

-- universal suffrage. 1 happiness is borderline useless to tall. add some tourism because its missing on T1

UPDATE Policies
SET
	ExtraHappinessPerCity = 0
	--,HappinessPerXPolicies = 3
	-- 3 because its 2 per tree
WHERE Type = 'POLICY_UNIVERSAL_SUFFRAGE';


UPDATE Language_en_US
SET Text = '[COLOR_POSITIVE_TEXT]Universal Suffrage[ENDCOLOR]: A [ICON_GOLDEN_AGE] Golden Age begins, and [ICON_GOLDEN_AGE] Golden Ages last 50% longer. Every World Congress Session, gain 10 [ICON_GOLDEN_AGE] Golden Age Points and [ICON_TOURISM] Tourism for every [ICON_DIPLOMAT] Delegate you control, scaling with Era.'
WHERE Tag = 'TXT_KEY_POLICY_UNIVERSAL_SUFFRAGE_HELP';

-- economic union. 6 gold is laughable. replace. 2 trade routes is v. strong for a t1 policy, but also very boring. chronology also wrong

INSERT INTO Policy_YieldFromDelegateCount
	(PolicyType, YieldType, Yield)
VALUES
	('POLICY_ECONOMIC_UNION', 'YIELD_GOLDEN_AGE_POINTS', 10),
	('POLICY_ECONOMIC_UNION', 'YIELD_TOURISM', 10);

UPDATE Policies SET
	Level = 2,
	FreeTradeRoute = 2,
	OpenBordersTourismModifier = 10
WHERE Type = 'POLICY_ECONOMIC_UNION';

INSERT INTO Policy_FreeBuilding
	(PolicyType, BuildingClassType, Count)
VALUES
	('POLICY_ECONOMIC_UNION', 'BUILDINGCLASS_STOCK_EXCHANGE', 5);
-- only 5 because its t1

UPDATE Language_en_US
SET Text = '[COLOR_POSITIVE_TEXT]Economic Union[ENDCOLOR]: +2 [ICON_INTERNATIONAL_TRADE] Trade Routes. Receive 5 [COLOR_POSITIVE_TEXT]Free[ENDCOLOR] Stock Exchanges. The [ICON_TOURISM] Tourism modifier for [COLOR_POSITIVE_TEXT]Open Borders[ENDCOLOR] with other Civilizations is increased by +10%.'
WHERE Tag = 'TXT_KEY_POLICY_ECONOMIC_UNION_HELP';

-- new deal. if we think about this, its way too weak for a t2 tenet. chronology also wrong

UPDATE Policies SET
	Level = 1
WHERE Type = 'POLICY_NEW_DEAL';

INSERT INTO Policy_WLTKDYieldMod
	(PolicyType, YieldType, Yield)
VALUES
	('POLICY_NEW_DEAL', 'YIELD_TOURISM', 10),
	('POLICY_NEW_DEAL', 'YIELD_GOLD', 10);

UPDATE Language_en_US
SET Text = '[COLOR_POSITIVE_TEXT]New Deal[ENDCOLOR]: Great Person Improvements produce +6 of a yield ([ICON_GREAT_ENGINEER]/[ICON_GREAT_GENERAL][ICON_PRODUCTION], [ICON_GREAT_MERCHANT][ICON_GOLD], [ICON_GREAT_SCIENTIST][ICON_RESEARCH], [ICON_DIPLOMAT][ICON_CULTURE], [ICON_PROPHET][ICON_PEACE]), and +2 [ICON_TOURISM] Tourism. [ICON_RES_ARTIFACTS] Landmarks produce +8 [ICON_TOURISM] Tourism. Cities generate +10% [ICON_GOLD] Gold and [ICON_TOURISM] Tourism during "We Love The King Day".'
WHERE Tag = 'TXT_KEY_POLICY_NEW_DEAL_HELP';

-- creative expression. weird wide bonus on a bunch of already-built buildings. replace

DELETE FROM Policy_BuildingClassYieldChanges WHERE PolicyType='POLICY_CREATIVE_EXPRESSION';

INSERT INTO Policy_YieldModifierFromGreatWorks
	(PolicyType, YieldType, Yield)
VALUES
	('POLICY_CREATIVE_EXPRESSION', 'YIELD_SCIENCE', 4);

UPDATE Language_en_US
SET Text = '[COLOR_POSITIVE_TEXT]Freedom of Speech[ENDCOLOR]: +2 [ICON_TOURISM] Tourism from [ICON_GREAT_WORK] Great Works. Cities generate +4% [ICON_RESEARCH] Science for every [ICON_GREAT_WORK] Great Work present (up to 20%).'
WHERE Tag = 'TXT_KEY_POLICY_CREATIVE_EXPRESSION_HELP';

UPDATE Language_en_US
SET Text = 'Freedom of Speech'
WHERE Tag = 'TXT_KEY_POLICY_CREATIVE_EXPRESSION';

-- capitalism. small boop to 3 things with some tourism 

UPDATE Policies SET
	TradeRouteTourismModifier = 10
WHERE Type = 'POLICY_CAPITALISM';

UPDATE Language_en_US
SET Text = '[COLOR_POSITIVE_TEXT]Capitalism[ENDCOLOR]: 2 [ICON_CITIZEN] Specialists in each of your cities generate +1 [ICON_HAPPINESS_1] Happiness instead of -1 [ICON_HAPPINESS_3] Unhappiness from Urbanization. Specialists generate +1 [ICON_GOLD] Gold and [ICON_RESEARCH] Science. The [ICON_TOURISM] Tourism modifier for [ICON_INTERNATIONAL_TRADE] Trade Routes with other Civilizations is increased by +10%.'
WHERE Tag = 'TXT_KEY_POLICY_CAPITALISM_HELP';
	



-- universal healthcare. also weak for t2 and hospital is probably already built in important cities

INSERT INTO Policy_YieldGPExpend
	(PolicyType, YieldType, Yield)
VALUES
	('POLICY_UNIVERSAL_HEALTHCARE_F', 'YIELD_FOOD', 100);

UPDATE Language_en_US
SET Text = '[COLOR_POSITIVE_TEXT]Universal Healthcare[ENDCOLOR]: Receive a [COLOR_POSITIVE_TEXT]Free[ENDCOLOR] Hospital in every City. +50 [ICON_CULTURE] when a Citizen is born in any City, scaling with Era. +100 [ICON_FOOD] Food in the [ICON_CAPITAL] Capital when you expend a [ICON_GREAT_PEOPLE] Great Person, scaling with Era.'
WHERE Tag = 'TXT_KEY_POLICY_UNIVERSAL_HEALTHCARE_F_HELP';

-- media culture. name is a bit negative and not inkeeping with theme of social democracy
-- beef up effect and make a bit more conditional i.e. requiring the synergy 

UPDATE Language_en_US
SET Text = 'Public Broadcasting'
WHERE Tag = 'TXT_KEY_POLICY_MEDIA_CULTURE';

UPDATE Language_en_US
SET Text = 'Public broadcasting (or public service broadcasting) involves radio, television, and other electronic media outlets whose primary mission is public service. Public broadcasters receive funding from diverse sources including license fees, individual contributions, public financing, and commercial financing, and claim to avoid both political interference and commercial influence. One of the principles of public broadcasting is to provide coverage of interests for which there are missing or small markets. Public broadcasting attempts to supply topics of social benefit that are otherwise not provided by commercial broadcasters. Additionally, public broadcasting may facilitate the implementation of a cultural policy (an industrial policy and investment policy for culture). For example, the Australian Broadcasting Corporation is legally required to "encourage and promote the musical, dramatic and other performing arts in Australia". As a result, these institutions face severe criticism from conservative politicians and think-tanks which allege that their programming has a leftist bias. At the same time, leftists often hold the opposite critique, disliking how close to political figures the controllers of such stations often are, or at least become.'
WHERE Tag = 'TXT_KEY_POLICY_MEDIA_CULTURE_TEXT';

UPDATE Language_en_US
SET Text = '[COLOR_POSITIVE_TEXT]Public Broadcasting[ENDCOLOR]: Broadcast Towers increase [ICON_CULTURE] Culture and [ICON_TOURISM] Tourism by 10%. Cities generate +10% [ICON_CULTURE] Culture and [ICON_TOURISM] Tourism during a [ICON_GOLDEN_AGE] Golden Age. +20% [ICON_TOURISM] Tourism to civilizations with less [ICON_HAPPINESS_1] Happiness.'
WHERE Tag = 'TXT_KEY_POLICY_MEDIA_CULTURE_HELP';

INSERT INTO Policy_GoldenAgeYieldMod
	(PolicyType, YieldType, Yield)
VALUES
	('POLICY_MEDIA_CULTURE', 'YIELD_TOURISM', 10),
	('POLICY_MEDIA_CULTURE', 'YIELD_CULTURE', 10);

DELETE FROM Policy_BuildingClassTourismModifiers WHERE PolicyType = 'POLICY_MEDIA_CULTURE';

-- not sure why the other table cant do this but ok lets not find out
INSERT INTO Policy_BuildingClassTourismModifiers
	(PolicyType, BuildingClassType, TourismModifier)
VALUES
	('POLICY_MEDIA_CULTURE', 'BUILDINGCLASS_BROADCAST_TOWER', 10);

INSERT INTO Policy_BuildingClassYieldModifiers
	(PolicyType, BuildingClassType, YieldType, YieldMod)
VALUES
	('POLICY_MEDIA_CULTURE', 'BUILDINGCLASS_BROADCAST_TOWER', 'YIELD_CULTURE', 10);

DELETE FROM Policy_BuildingClassHappiness WHERE PolicyType = 'POLICY_MEDIA_CULTURE';
DELETE FROM Policy_BuildingClassYieldModifiers WHERE PolicyType = 'POLICY_MEDIA_CULTURE';

UPDATE Policies
SET LessHappyTourismModifier = 20
WHERE Type = 'POLICY_MEDIA_CULTURE';

-- space procurement. strong 20% but bit boring; text is not standardized
-- because we have the great work bonus now, we need to nerf this or its like 40% science increase: too much

UPDATE Language_en_US
SET Text = '[COLOR_POSITIVE_TEXT]Space Procurements[ENDCOLOR]: May invest in [COLOR_POSITIVE_TEXT]Spaceship Parts[ENDCOLOR] with [ICON_GOLD] Gold. Cities generate +100% [ICON_PRODUCTION] Production towards Spaceship Factories. You receive +400% more [ICON_RESEARCH] Science from [ICON_INTERNATIONAL_TRADE] Trade Routes.'
WHERE Tag = 'TXT_KEY_POLICY_SPACE_PROCUREMENTS_HELP';

DELETE FROM Policy_BuildingClassYieldModifiers WHERE PolicyType = 'POLICY_SPACE_PROCUREMENTS';

INSERT INTO Policy_InternationalRouteYieldModifiers
	(PolicyType, YieldType, Yield)
VALUES
	('POLICY_SPACE_PROCUREMENTS', 'YIELD_SCIENCE', 400);

-- containment. only does 2 things, although they are very good.
UPDATE Policies
SET
	ProtectedMinorPerTurnInfluence = 200,
	FreeWCVotes = 3
WHERE Type = 'POLICY_TREATY_ORGANIZATION';

UPDATE Language_en_US
SET Text = '[COLOR_POSITIVE_TEXT]Containment[ENDCOLOR]: [ICON_INTERNATIONAL_TRADE] Trade Routes to [ICON_CITY_STATE] City-States generate +2 [ICON_INFLUENCE] Influence per turn with them per owned City-State Trade Route (up to +10). +1 [ICON_DIPLOMAT] Delegate in the World Congress for every 3 [ICON_CITY_STATE] City-States originally in the World.'
WHERE Tag = 'TXT_KEY_POLICY_TREATY_ORGANIZATION_HELP';


-- text changes
UPDATE Language_en_US
SET Text = '[COLOR_POSITIVE_TEXT]Their Finest Hour[ENDCOLOR]: All cities get +2 [ICON_AIRPORT] Air Unit Slots. Each Air Unit stationed in a city increases the City''s [ICON_STRENGTH] Defense by 3. Can build [COLOR_YELLOW]B17 Bombers[ENDCOLOR].'
WHERE Tag = 'TXT_KEY_POLICY_THEIR_FINEST_HOUR_HELP';

UPDATE Language_en_US
SET Text = '[COLOR_POSITIVE_TEXT]Self Determination[ENDCOLOR]: [COLOR_POSITIVE_TEXT]Liberating[ENDCOLOR] a City gives 15 XP to all Units, 50 [ICON_INFLUENCE] Influence with all [ICON_CITY_STATE] City-States, and 40 [ICON_RESEARCH] Science, scaling with Era and City [ICON_CITIZEN] Population. The Liberated City gains an Arsenal and 6 Units.'
WHERE Tag = 'TXT_KEY_POLICY_URBANIZATION_HELP';